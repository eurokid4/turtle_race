# Hello!
thank you for trying turtle race.

Current version:  
# v6.0